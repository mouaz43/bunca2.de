# Deploy from GitHub (works with full backend)

GitHub Pages cannot run Node.js/Express apps (no backend). For this project you **push the code to GitHub**, then deploy the app on a Node host that connects to your repo.

## Option A — Render (free tier)

1. Push this folder to a new GitHub repo (e.g., `bunca-ordering`).
2. Go to render.com → **New +** → **Blueprint** → paste your repo URL.
3. Render reads `render.yaml`. Confirm:
   - **Build:** `npm install`
   - **Start:** `npm start`
   - **Node:** 20
   - **Disk:** mounted at `/opt/render/project/src/data` (for SQLite)
4. Set environment variables (you can copy from `.env.sample`):
   - `SESSION_SECRET` (any long random string)
   - `BASE_URL` (after first deploy, set to your Render URL and redeploy)
   - Optional: SMTP_* for email, TWILIO_* for WhatsApp
   - Optional: `ADMIN_EMAIL`, `ADMIN_PASSWORD` to auto-create admin at first boot
5. Click **Deploy**. When live, update `BASE_URL` to your Render domain and redeploy.

## Option B — Railway (Dockerfile)

1. Push to GitHub.
2. On railway.app create a new project **from GitHub**. It detects the `Dockerfile`.
3. Add **Environment Variables** from `.env.sample`.
4. Add a **Persistent Volume** and mount it at `/app/data`.
5. Deploy.

## Option C — Fly.io

1. Install `flyctl`, run `fly launch` in the repo (uses Dockerfile).
2. `fly volumes create bunca_data --size 1`
3. Mount volume at `/app/data` in `fly.toml`, then `fly deploy`.

---

### After deploy

- Open the live URL.
- Visit `/signup` (or rely on `ADMIN_EMAIL`/`ADMIN_PASSWORD` to auto-create an admin).
- Go to **Admin → Items** and add inventory.
- Start placing orders at `/` → confirm → notify (email/WhatsApp).

> If you want GH Pages just for a landing page, you can keep a static site in `/public` that links to your hosted app.

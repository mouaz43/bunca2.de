import twilio from 'twilio';

export async function sendWhatsAppWithPDF({ toNumber, message, mediaUrl }) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_WHATSAPP_FROM; // 'whatsapp:+1...'
  if (!sid || !token || !from) {
    throw new Error('Twilio WhatsApp vars missing');
  }
  const client = twilio(sid, token);
  const msg = await client.messages.create({
    from,
    to: `whatsapp:${toNumber.replace(/^whatsapp:/,'').trim()}`,
    body: message,
    mediaUrl: mediaUrl ? [mediaUrl] : undefined
  });
  return msg;
}

import 'dotenv/config.js';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import session from 'express-session';
import connectSqlite3 from 'connect-sqlite3';
import bcrypt from 'bcrypt';
import fs from 'fs';

import { db, init as initDb, run, get, all } from './db.js';
import { generateOrderPDF } from './utils/pdf.js';
import { sendEmailWithPDF } from './utils/email.js';
import { sendWhatsAppWithPDF } from './utils/whatsapp.js';
import { requireAuth, requireAdmin } from './utils/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const SQLiteStore = connectSqlite3(session);

await initDb();

// bootstrap admin if provided
async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const pass = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME || 'Admin';
  const phone = process.env.ADMIN_PHONE || '';
  if (!email || !pass) return;
  const existing = await get('SELECT * FROM users WHERE email = ?', [email]);
  if (!existing) {
    const hash = await bcrypt.hash(pass, 10);
    await run('INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)',
      [name, email, phone, hash, 'admin']);
    console.log('Admin user created:', email);
  }
}
await ensureAdmin();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: './data' }),
  secret: process.env.SESSION_SECRET || 'dev-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // set true behind HTTPS proxy
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/pdfs', express.static(path.join(__dirname, 'pdfs')));

app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  next();
});

// ------------- AUTH -------------
app.get('/signup', (req, res) => {
  res.render('signup', { error: null });
});

app.post('/signup', async (req, res) => {
  const { name, email, phone, password } = req.body;
  try {
    const existing = await get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) return res.render('signup', { error: 'Email already registered.' });
    const hash = await bcrypt.hash(password, 10);
    await run('INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)',
      [name, email, phone || '', hash, 'user']);
    res.redirect('/login');
  } catch (e) {
    res.render('signup', { error: e.message });
  }
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await get('SELECT * FROM users WHERE email = ?', [email]);
  if (!user) return res.render('login', { error: 'Invalid credentials.' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.render('login', { error: 'Invalid credentials.' });
  req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role };
  res.redirect('/');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// ------------- ORDER FLOW -------------
// Order form
app.get('/', requireAuth, async (req, res) => {
  const items = await all('SELECT * FROM items ORDER BY category, name');
  res.render('index', { items, pending: req.session.pendingOrder || null });
});

app.post('/confirm', requireAuth, async (req, res) => {
  // Parse form quantities like qty_<itemId>
  const items = await all('SELECT * FROM items ORDER BY name');
  const orderItems = [];
  for (const it of items) {
    const key = `qty_${it.id}`;
    const raw = req.body[key];
    const qty = raw ? parseFloat(raw) : 0;
    if (!isNaN(qty) && qty > 0) {
      orderItems.push({ item_id: it.id, item_name: it.name, unit: it.unit || 'pcs', quantity: qty });
    }
  }
  const { branch, note } = req.body;
  req.session.pendingOrder = { branch, note, items: orderItems };
  if (orderItems.length === 0) {
    return res.redirect('/');
  }
  res.render('confirm', { order: req.session.pendingOrder });
});

app.post('/place-order', requireAuth, async (req, res) => {
  // From confirm to notify step (no DB write yet)
  res.redirect('/notify');
});

app.get('/notify', requireAuth, (req, res) => {
  const pending = req.session.pendingOrder;
  if (!pending) return res.redirect('/');
  res.render('notify', { error: null, pending });
});

app.post('/notify', requireAuth, async (req, res) => {
  const pending = req.session.pendingOrder;
  if (!pending) return res.redirect('/');

  const { emails, whatsapps } = req.body; // comma-separated
  const user = req.session.user;

  // Save order
  const r = await run('INSERT INTO orders (user_id, branch, note, notify_email, notify_whatsapp) VALUES (?,?,?,?,?)',
    [user.id, pending.branch || '', pending.note || '', emails || '', whatsapps || '']);
  const orderId = r.lastID;

  for (const it of pending.items) {
    await run('INSERT INTO order_items (order_id, item_id, item_name, unit, quantity) VALUES (?,?,?,?,?)',
      [orderId, it.item_id, it.item_name, it.unit, it.quantity]);
  }

  // Generate PDF
  const orderRow = await get(`SELECT o.*, u.name as user_name, u.email as user_email
                              FROM orders o LEFT JOIN users u ON o.user_id = u.id
                              WHERE o.id = ?`, [orderId]);
  const items = await all('SELECT * FROM order_items WHERE order_id = ?', [orderId]);

  const outDir = path.resolve('./pdfs');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const { filename, outPath } = generateOrderPDF({ order: orderRow, items, outDir });

  await run('UPDATE orders SET pdf_filename = ? WHERE id = ?', [filename, orderId]);

  // Send notifications (best-effort)
  const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
  const pdfPublicUrl = `${baseUrl}/pdfs/${filename}`;

  // Email
  if (emails) {
    const list = emails.split(',').map(s => s.trim()).filter(Boolean);
    if (list.length) {
      try {
        await sendEmailWithPDF({
          to: list.join(','),
          subject: `Bunca Order #${orderId}`,
          html: `<p>New order placed from <b>${orderRow.branch || 'Bunca'}</b>.</p>
                 <p>Download PDF: <a href="${pdfPublicUrl}">${pdfPublicUrl}</a></p>`,
          pdfPath: outPath
        });
      } catch (e) {
        console.error('Email error:', e.message);
      }
    }
  }

  // WhatsApp
  if (whatsapps) {
    const list = whatsapps.split(',').map(s => s.trim()).filter(Boolean);
    for (const num of list) {
      try {
        await sendWhatsAppWithPDF({
          toNumber: num,
          message: `Bunca Order #${orderId} — Branch: ${orderRow.branch || 'Bunca'}.
PDF: ${pdfPublicUrl}`,
          mediaUrl: pdfPublicUrl
        });
      } catch (e) {
        console.error('WhatsApp error:', e.message);
      }
    }
  }

  // Clear pending
  req.session.pendingOrder = null;
  res.redirect(`/success?id=${orderId}`);
});

app.get('/success', requireAuth, async (req, res) => {
  const { id } = req.query;
  res.render('success', { id });
});

// ------------- ADMIN -------------
app.get('/admin', requireAuth, requireAdmin, async (req, res) => {
  const totalItems = await get('SELECT COUNT(*) as c FROM items');
  const totalOrders = await get('SELECT COUNT(*) as c FROM orders');
  const totalUsers = await get('SELECT COUNT(*) as c FROM users');
  res.render('admin/dashboard', { totalItems: totalItems.c, totalOrders: totalOrders.c, totalUsers: totalUsers.c });
});

app.get('/admin/items', requireAuth, requireAdmin, async (req, res) => {
  const items = await all('SELECT * FROM items ORDER BY category, name');
  res.render('admin/items', { items });
});

app.get('/admin/items/new', requireAuth, requireAdmin, async (req, res) => {
  res.render('admin/item_form', { item: null });
});

app.post('/admin/items', requireAuth, requireAdmin, async (req, res) => {
  const { name, category, unit, quantity, min_quantity, in_stock } = req.body;
  await run('INSERT INTO items (name, category, unit, quantity, min_quantity, in_stock) VALUES (?,?,?,?,?,?)',
    [name, category || '', unit || 'pcs', quantity || 0, min_quantity || 0, in_stock ? 1 : 0]);
  res.redirect('/admin/items');
});

app.get('/admin/items/:id/edit', requireAuth, requireAdmin, async (req, res) => {
  const item = await get('SELECT * FROM items WHERE id = ?', [req.params.id]);
  res.render('admin/item_form', { item });
});

app.post('/admin/items/:id/update', requireAuth, requireAdmin, async (req, res) => {
  const { name, category, unit, quantity, min_quantity, in_stock } = req.body;
  await run('UPDATE items SET name=?, category=?, unit=?, quantity=?, min_quantity=?, in_stock=? WHERE id=?',
    [name, category || '', unit || 'pcs', quantity || 0, min_quantity || 0, in_stock ? 1 : 0, req.params.id]);
  res.redirect('/admin/items');
});

app.post('/admin/items/:id/delete', requireAuth, requireAdmin, async (req, res) => {
  await run('DELETE FROM items WHERE id = ?', [req.params.id]);
  res.redirect('/admin/items');
});

app.get('/admin/orders', requireAuth, requireAdmin, async (req, res) => {
  const orders = await all(`SELECT o.*, u.name as user_name
                             FROM orders o LEFT JOIN users u ON o.user_id = u.id
                             ORDER BY o.id DESC LIMIT 200`);
  res.render('admin/orders', { orders });
});

// ------------- UI Templates -------------
// Helper to provide default title
app.locals.title = 'Bunca. Coffee Ordering';

// ------------- START -------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Bunca app running on :' + PORT));

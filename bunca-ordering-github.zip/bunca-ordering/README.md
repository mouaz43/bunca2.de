# Bunca. Coffee — Ordering App (Store ➜ Warehouse)

A full-stack app to let Bunca shops place inventory orders to your warehouse.
It generates a PDF of the order and can notify via **email** and/or **WhatsApp**.
Includes:
- **Order page** (multi-item with quantities)
- **Order confirmation** and **notification** step
- **Admin** panel: items, stock, quantities, orders, user roles
- **Signup/Login** (role-based: admin, user)
- Clean specialty-coffee design

---

## 1) Quick Start (Local)

1. Install Node.js **18+**.
2. Clone or unzip this project.
3. Create `.env` from the sample:
   ```bash
   cp .env.sample .env
   ```
   - Change `SESSION_SECRET` to a long random string.
   - (Optional) Set `ADMIN_*` to auto-create an admin on first run.
   - (Optional) Fill SMTP and Twilio vars if you want email/WhatsApp notifications.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Run the app:
   ```bash
   npm start
   ```
6. Open http://localhost:3000

**First admin user**: If you set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `.env`, the server will create that admin at startup (only if it doesn't exist). Otherwise, sign up at `/signup` and have an existing admin promote you.

---

## 2) Deploy (any Node host)

This is a standard Node + SQLite app. Typical steps (Render, Fly.io, Railway, etc.):

- Add a new **Web Service** from your GitHub repo or upload the zip.
- Set **Node** runtime and build command `npm install`.
- Set start command `npm start`.
- Add all required **Environment Variables** from `.env.sample`.
- Set `BASE_URL` to your public URL (important for WhatsApp PDF links).
- Ensure persistent storage if your host requires it (for `/data/bunca.db` and `/pdfs`).

> SQLite stores data in `./data/bunca.db`. If your host doesn't persist disk between restarts, use its persistent volume feature.

---

## 3) WhatsApp & Email

- **Email**: Works with any SMTP (e.g., Gmail with App Password). The PDF is directly attached.
- **WhatsApp (Twilio)**: Requires a WhatsApp-enabled number + approved template.
  - Set `TWILIO_*` and `TWILIO_WHATSAPP_FROM` in `.env`.
  - Set `BASE_URL` to your public HTTPS URL so Twilio can fetch the PDF at `/pdfs/<file>.pdf`.

---

## 4) Default URLs

- `/` — Order page
- `/confirm` — Review your order
- `/notify` — Choose recipients (email/WhatsApp)
- `/success` — Done
- `/signup`, `/login`, `/logout`
- `/admin` — Dashboard (admin only)
- `/admin/items` — Manage inventory
- `/admin/orders` — View orders

---

## 5) Notes

- This project is self-contained: **no external DB**, just SQLite.
- If you need SSO or more advanced auth later, you can add it easily.
- Design uses Tailwind via CDN (no build step).

---

## 6) Seed initial items (optional)

Log in as **admin**, go to **Admin → Items → New Item** and add items that are available for ordering. You can also set quantities and mark items as out of stock.

---

## 7) Security & Production Hardening (later)

- Change all secrets.
- Use HTTPS in production.
- Set proper CORS and session cookie flags.
- Add CSRF if you want extra protection.
